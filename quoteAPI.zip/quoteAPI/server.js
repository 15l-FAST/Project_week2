const express = require('express'); //import express

const app = express(); //instance of express server

const { quotes } = require('./data');
const { getRandomElement } = require('./utils');

const PORT = process.env.PORT || 4001; // specify port number

/* get the server listening on the specified port */

app.listen(PORT, () => {
    console.log("server is listening on port" + PORT)
});

/* RANDOM QUOTE  */

app.get("/api/quotes/random", (req, res, next) => {
    const randQuote = getRandomElement(quotes);
    console.log("random quote", randQuote);
    res.send({ quote: randQuote });
})

/* Quote from a specific person*/
/*app.get("/api/quotes", (req, res, next) => {

    const person = req.query.person;
    if (person) {
        const quotes_byAuthor = quotes.filter((quotes) => quotes.person == person);
    }
    console.log(quotes.length);
    res.send(quotes).status();
})
*/

app.get('/api/quotes', (req, res) => {
    const filterQuotes = quotes.filter(author => {
        return author.person === req.query.person;
    });
    if (req.query.person) {
        res.send({ quotes: filterQuotes });
    } else {
        res.send({ quotes: quotes });
    }
});

/*add new quote */
app.post('/api/quotes/', (req, res, next) => {
    const newQuote = req.query.quote;
    const newPerson = req.query.person;

    if (newQuote != "" && newPerson != " ") {
        quotes.push({ quote: newQuote, person: newPerson });
        res.send({ quote: { quote: newQuote, person: newPerson } });
    } else
        res.status(400).send();

})

app.use(express.static('public'));